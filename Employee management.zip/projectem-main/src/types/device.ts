export type DeviceStatus = 'active' | 'warning' | 'offline';

export interface Device {
  deviceId: string;
  name: string;
  status: DeviceStatus;
  temperature: number | null;
  voltage: number | null;
}

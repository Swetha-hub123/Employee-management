import { Device, DeviceStatus } from '@/types/device';

// Mock data matching the assignment requirements
export const mockDevices: Device[] = [
  {
    deviceId: "A02130825",
    name: "Battery Pack 01",
    status: "active",
    temperature: 32,
    voltage: 48.5
  },
  {
    deviceId: "A02130826",
    name: "Battery Pack 02",
    status: "warning",
    temperature: 44,
    voltage: 47.9
  },
  {
    deviceId: "A02130827",
    name: "Battery Pack 03",
    status: "offline",
    temperature: null,
    voltage: null
  }
];

// Simulate API call with optional status filter
export const fetchDevices = async (status?: DeviceStatus): Promise<Device[]> => {
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  let data = mockDevices;
  
  if (status) {
    data = data.filter(device => device.status === status);
  }
  
  return data;
};

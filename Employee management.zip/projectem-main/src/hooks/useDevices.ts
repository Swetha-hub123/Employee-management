import { useQuery } from '@tanstack/react-query';
import { Device, DeviceStatus } from '@/types/device';
import { fetchDevices } from '@/data/mockDevices';

// API base URL - change this when connecting to real backend
const API_BASE_URL = 'http://localhost:3001';

// Set to true when backend is running, false for mock data
const USE_REAL_API = false;

async function getDevices(status?: DeviceStatus): Promise<Device[]> {
  if (USE_REAL_API) {
    const url = status 
      ? `${API_BASE_URL}/api/devices?status=${status}`
      : `${API_BASE_URL}/api/devices`;
    
    const response = await fetch(url);
    
    if (!response.ok) {
      throw new Error('Failed to fetch devices');
    }
    
    return response.json();
  }
  
  // Use mock data
  return fetchDevices(status);
}

export function useDevices(status?: DeviceStatus) {
  return useQuery({
    queryKey: ['devices', status],
    queryFn: () => getDevices(status),
    staleTime: 30000, // Consider data fresh for 30 seconds
  });
}

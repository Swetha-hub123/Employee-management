import { DeviceStatus } from '@/types/device';
import { cn } from '@/lib/utils';
import { Filter } from 'lucide-react';

interface StatusFilterProps {
  selectedStatus: DeviceStatus | undefined;
  onStatusChange: (status: DeviceStatus | undefined) => void;
}

const statusOptions: { value: DeviceStatus | undefined; label: string }[] = [
  { value: undefined, label: 'All Devices' },
  { value: 'active', label: 'Active' },
  { value: 'warning', label: 'Warning' },
  { value: 'offline', label: 'Offline' },
];

export function StatusFilter({ selectedStatus, onStatusChange }: StatusFilterProps) {
  return (
    <div className="flex items-center gap-2">
      <Filter className="h-4 w-4 text-muted-foreground" />
      <select
        value={selectedStatus ?? ''}
        onChange={(e) => onStatusChange(e.target.value as DeviceStatus | undefined || undefined)}
        className={cn(
          'rounded-lg border border-border bg-card px-3 py-2 text-sm font-medium text-foreground',
          'transition-smooth focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20',
          'cursor-pointer hover:border-primary/50'
        )}
      >
        {statusOptions.map((option) => (
          <option key={option.label} value={option.value ?? ''}>
            {option.label}
          </option>
        ))}
      </select>
    </div>
  );
}

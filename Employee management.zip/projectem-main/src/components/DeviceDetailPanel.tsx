import { Device } from '@/types/device';
import { StatusBadge } from './StatusBadge';
import { X, Thermometer, Zap, Hash, Battery, Activity } from 'lucide-react';
import { cn } from '@/lib/utils';

interface DeviceDetailPanelProps {
  device: Device | null;
  onClose: () => void;
}

export function DeviceDetailPanel({ device, onClose }: DeviceDetailPanelProps) {
  if (!device) return null;
  
  const isOffline = device.status === 'offline';
  
  return (
    <div className="animate-slide-in-right h-full w-full overflow-hidden rounded-lg border border-border bg-card/95 backdrop-blur-lg">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-border px-6 py-4">
        <h2 className="font-semibold text-foreground">Device Details</h2>
        <button
          onClick={onClose}
          className="rounded-lg p-2 text-muted-foreground transition-smooth hover:bg-muted hover:text-foreground"
        >
          <X className="h-4 w-4" />
        </button>
      </div>
      
      {/* Content */}
      <div className="p-6">
        {/* Device name and status */}
        <div className="mb-6 flex items-center gap-4">
          <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-primary/10">
            <Battery className="h-7 w-7 text-primary" />
          </div>
          <div>
            <h3 className="text-xl font-semibold text-foreground">{device.name}</h3>
            <StatusBadge status={device.status} className="mt-1" />
          </div>
        </div>
        
        {/* Device ID */}
        <div className="mb-6">
          <DetailRow
            icon={<Hash className="h-4 w-4" />}
            label="Device ID"
            value={device.deviceId}
            mono
          />
        </div>
        
        {/* Metrics */}
        <div className="space-y-4">
          <h4 className="text-xs uppercase tracking-wider text-muted-foreground">Metrics</h4>
          
          <div className={cn(
            'rounded-lg border border-border bg-muted/30 p-4',
            isOffline && 'opacity-50'
          )}>
            <div className="flex items-center gap-3">
              <div className={cn(
                'flex h-10 w-10 items-center justify-center rounded-lg',
                device.status === 'warning' ? 'bg-status-warning/10' : 'bg-primary/10'
              )}>
                <Thermometer className={cn(
                  'h-5 w-5',
                  device.status === 'warning' ? 'text-status-warning' : 'text-primary'
                )} />
              </div>
              <div className="flex-1">
                <p className="text-sm text-muted-foreground">Temperature</p>
                <p className="font-mono text-2xl font-semibold text-foreground">
                  {device.temperature !== null ? `${device.temperature}°C` : 'N/A'}
                </p>
              </div>
              {device.status === 'warning' && device.temperature && device.temperature > 40 && (
                <div className="rounded-md bg-status-warning/10 px-2 py-1">
                  <span className="text-xs font-medium text-status-warning">High</span>
                </div>
              )}
            </div>
          </div>
          
          <div className={cn(
            'rounded-lg border border-border bg-muted/30 p-4',
            isOffline && 'opacity-50'
          )}>
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                <Zap className="h-5 w-5 text-primary" />
              </div>
              <div className="flex-1">
                <p className="text-sm text-muted-foreground">Voltage</p>
                <p className="font-mono text-2xl font-semibold text-foreground">
                  {device.voltage !== null ? `${device.voltage}V` : 'N/A'}
                </p>
              </div>
            </div>
          </div>
          
          <div className="rounded-lg border border-border bg-muted/30 p-4">
            <div className="flex items-center gap-3">
              <div className={cn(
                'flex h-10 w-10 items-center justify-center rounded-lg',
                isOffline ? 'bg-status-offline/10' : 'bg-status-active/10'
              )}>
                <Activity className={cn(
                  'h-5 w-5',
                  isOffline ? 'text-status-offline' : 'text-status-active'
                )} />
              </div>
              <div className="flex-1">
                <p className="text-sm text-muted-foreground">Status</p>
                <p className={cn(
                  'text-lg font-semibold capitalize',
                  device.status === 'active' && 'text-status-active',
                  device.status === 'warning' && 'text-status-warning',
                  device.status === 'offline' && 'text-status-offline'
                )}>
                  {device.status}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

interface DetailRowProps {
  icon: React.ReactNode;
  label: string;
  value: string | number | null;
  mono?: boolean;
}

function DetailRow({ icon, label, value, mono }: DetailRowProps) {
  return (
    <div className="flex items-center gap-3 rounded-lg border border-border bg-muted/30 px-4 py-3">
      <span className="text-muted-foreground">{icon}</span>
      <div className="flex-1">
        <p className="text-xs text-muted-foreground">{label}</p>
        <p className={cn('text-sm font-medium text-foreground', mono && 'font-mono')}>
          {value ?? 'N/A'}
        </p>
      </div>
    </div>
  );
}

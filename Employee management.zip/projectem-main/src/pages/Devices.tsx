import { useState } from 'react';
import { Device, DeviceStatus } from '@/types/device';
import { useDevices } from '@/hooks/useDevices';
import { DeviceCard } from '@/components/DeviceCard';
import { DeviceDetailPanel } from '@/components/DeviceDetailPanel';
import { StatusFilter } from '@/components/StatusFilter';
import { LoadingState } from '@/components/LoadingState';
import { ErrorState } from '@/components/ErrorState';
import { DashboardHeader } from '@/components/DashboardHeader';
import { cn } from '@/lib/utils';

export default function Devices() {
  const [selectedStatus, setSelectedStatus] = useState<DeviceStatus | undefined>();
  const [selectedDevice, setSelectedDevice] = useState<Device | null>(null);
  
  const { data: devices, isLoading, isError, refetch } = useDevices(selectedStatus);
  
  const handleDeviceClick = (device: Device) => {
    setSelectedDevice(device);
  };
  
  const handleClosePanel = () => {
    setSelectedDevice(null);
  };
  
  return (
    <div className="flex min-h-screen flex-col bg-background bg-grid-pattern">
      {/* Ambient glow effect */}
      <div className="pointer-events-none fixed inset-0 overflow-hidden">
        <div className="absolute -top-40 left-1/2 h-80 w-[600px] -translate-x-1/2 rounded-full bg-primary/5 blur-3xl" />
      </div>
      
      <DashboardHeader />
      
      <main className="relative flex-1">
        <div className="container px-4 py-6 sm:px-6 sm:py-8">
          {/* Page header */}
          <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h2 className="text-2xl font-bold text-foreground sm:text-3xl">Devices</h2>
              <p className="mt-1 text-sm text-muted-foreground">
                Monitor and manage your EV battery packs
              </p>
            </div>
            <StatusFilter 
              selectedStatus={selectedStatus} 
              onStatusChange={setSelectedStatus} 
            />
          </div>
          
          {/* Main content area */}
          <div className="flex gap-6">
            {/* Device list */}
            <div className={cn(
              'flex-1 transition-all duration-300',
              selectedDevice ? 'lg:pr-[380px]' : ''
            )}>
              {isLoading ? (
                <LoadingState />
              ) : isError ? (
                <ErrorState onRetry={() => refetch()} />
              ) : devices && devices.length > 0 ? (
                <div className="stagger-children grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  {devices.map((device) => (
                    <DeviceCard
                      key={device.deviceId}
                      device={device}
                      onClick={handleDeviceClick}
                      isSelected={selectedDevice?.deviceId === device.deviceId}
                    />
                  ))}
                </div>
              ) : (
                <div className="rounded-lg border border-border bg-card px-8 py-12 text-center">
                  <p className="text-muted-foreground">No devices found</p>
                  {selectedStatus && (
                    <button
                      onClick={() => setSelectedStatus(undefined)}
                      className="mt-2 text-sm text-primary hover:underline"
                    >
                      Clear filter
                    </button>
                  )}
                </div>
              )}
            </div>
            
            {/* Detail panel - fixed position on larger screens */}
            {selectedDevice && (
              <div className="fixed bottom-0 right-0 top-16 z-40 w-full border-l border-border bg-background/95 backdrop-blur-lg sm:w-[380px] lg:w-[360px]">
                <DeviceDetailPanel device={selectedDevice} onClose={handleClosePanel} />
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}

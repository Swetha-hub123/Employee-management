import Devices from './Devices';

// The main index page renders the Devices dashboard
const Index = () => {
  return <Devices />;
};

export default Index;
